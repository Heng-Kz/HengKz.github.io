const myImage = document.querySelector("img");

myImage.onclick = () => {
    const mySrc = myImage.getAttribute("src");
    if (mySrc === "images/e1c17a50c356e93243698d5feeee0f8c401742377.jpg") {
        myImage.setAttribute("src", "images/630b82424809a657f12553169820abf5.png");
    } else {
        myImage.setAttribute("src", "images/e1c17a50c356e93243698d5feeee0f8c401742377.jpg");
    }
};
let myButton = document.querySelector("button");
let myHeading = document.querySelector("h1");
function setUserName() {
    const myName = prompt("Please enter your name.");
    if (!myName) {
        setUserName();
    } else {
        localStorage.setItem("name", myName);
        myHeading.textContent = `Mozilla is cool, ${myName}`;
    }
}
if (!localStorage.getItem("name")) {
    setUserName();
} else {
    const storedName = localStorage.getItem("name");
    myHeading.textContent = `Mozilla is cool, ${storedName}`;
}
myButton.onclick = function () {
    setUserName();
};